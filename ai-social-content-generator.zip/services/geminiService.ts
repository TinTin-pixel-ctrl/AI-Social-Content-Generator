
import { GoogleGenAI, Type } from "@google/genai";
// Fix: Changed `import type` to a standard `import` to allow the `Platform` enum to be used as a value at runtime.
import { Platform, type GeneratedPost, type Tone, type AspectRatio } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const textModel = "gemini-2.5-pro";
const imageModel = "imagen-4.0-generate-001";

const generateTextContent = async (idea: string, tone: Tone): Promise<Record<Platform, GeneratedPost>> => {
  const prompt = `
    Based on the following idea and tone, generate social media posts tailored for LinkedIn, Twitter/X, and Instagram.

    Idea: "${idea}"
    Tone: "${tone}"

    For each platform, provide:
    1. "post": The text content of the post, optimized for the platform's style and length.
       - LinkedIn: Professional, longer-form, insightful.
       - Twitter/X: Short, punchy, engaging, max 280 characters.
       - Instagram: Visually focused caption with relevant hashtags.
    2. "imagePrompt": A detailed, creative, and visually rich prompt for an AI image generator to create a compelling image that complements the post. This prompt should be a sentence or two describing a scene.

    Return the response as a JSON object.
  `;

  const response = await ai.models.generateContent({
    model: textModel,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          [Platform.LinkedIn]: {
            type: Type.OBJECT,
            properties: {
              post: { type: Type.STRING },
              imagePrompt: { type: Type.STRING },
            },
          },
          [Platform.Twitter]: {
            type: Type.OBJECT,
            properties: {
              post: { type: Type.STRING },
              imagePrompt: { type: Type.STRING },
            },
          },
          [Platform.Instagram]: {
            type: Type.OBJECT,
            properties: {
              post: { type: Type.STRING },
              imagePrompt: { type: Type.STRING },
            },
          },
        },
      },
    },
  });
  
  const jsonText = response.text.trim();
  return JSON.parse(jsonText);
};

const generateImage = async (prompt: string, aspectRatio: AspectRatio): Promise<string> => {
    const response = await ai.models.generateImages({
        model: imageModel,
        prompt: prompt,
        config: {
            numberOfImages: 1,
            aspectRatio: aspectRatio,
            outputMimeType: 'image/jpeg',
        },
    });

    const base64ImageBytes = response.generatedImages[0].image.imageBytes;
    return `data:image/jpeg;base64,${base64ImageBytes}`;
};

export const generateAllContent = async (idea: string, tone: Tone) => {
    const textData = await generateTextContent(idea, tone);

    const [linkedInImage, twitterImage, instagramImage] = await Promise.all([
        generateImage(textData.LinkedIn.imagePrompt, '16:9'),
        generateImage(textData.Twitter.imagePrompt, '16:9'),
        generateImage(textData.Instagram.imagePrompt, '9:16'),
    ]);

    return {
        [Platform.LinkedIn]: { ...textData.LinkedIn, imageUrl: linkedInImage },
        [Platform.Twitter]: { ...textData.Twitter, imageUrl: twitterImage },
        [Platform.Instagram]: { ...textData.Instagram, imageUrl: instagramImage },
    };
};
