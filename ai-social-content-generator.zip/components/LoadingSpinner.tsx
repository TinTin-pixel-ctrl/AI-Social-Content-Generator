
import React from 'react';

const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex justify-center items-center p-4">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-400"></div>
    </div>
  );
};

export const ContentSkeleton: React.FC = () => {
    return (
        <div className="w-full bg-gray-800 rounded-lg shadow-lg overflow-hidden animate-pulse">
            <div className="p-4 border-b border-gray-700 flex items-center space-x-3">
                <div className="w-8 h-8 bg-gray-700 rounded-full"></div>
                <div className="w-1/3 h-6 bg-gray-700 rounded"></div>
            </div>
            <div className="aspect-[16/9] bg-gray-700 w-full"></div>
            <div className="p-4 space-y-3">
                <div className="h-4 bg-gray-700 rounded w-full"></div>
                <div className="h-4 bg-gray-700 rounded w-5/6"></div>
                <div className="h-4 bg-gray-700 rounded w-3/4"></div>
            </div>
        </div>
    );
};
