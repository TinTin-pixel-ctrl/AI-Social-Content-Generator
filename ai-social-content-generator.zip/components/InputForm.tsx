
import React from 'react';
import { Tone } from '../types';

interface InputFormProps {
  idea: string;
  setIdea: (idea: string) => void;
  tone: Tone;
  setTone: (tone: Tone) => void;
  onSubmit: (e: React.FormEvent) => void;
  isLoading: boolean;
}

export const InputForm: React.FC<InputFormProps> = ({ idea, setIdea, tone, setTone, onSubmit, isLoading }) => {
  return (
    <form onSubmit={onSubmit} className="w-full space-y-6">
      <div>
        <label htmlFor="idea" className="block text-sm font-medium text-gray-300 mb-2">
          Your Content Idea
        </label>
        <textarea
          id="idea"
          rows={4}
          className="w-full bg-gray-800 border border-gray-600 rounded-lg shadow-sm focus:ring-purple-500 focus:border-purple-500 transition duration-150 p-4 text-white placeholder-gray-400"
          placeholder="e.g., Launching a new productivity app that uses AI..."
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
          disabled={isLoading}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Select Tone
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {Object.values(Tone).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTone(t)}
              disabled={isLoading}
              className={`px-4 py-2 text-sm font-semibold rounded-lg transition duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-purple-500
                ${tone === t ? 'bg-purple-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}
                ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div>
        <button
          type="submit"
          disabled={isLoading || !idea.trim()}
          className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-purple-500 disabled:bg-gray-500 disabled:cursor-not-allowed transition duration-150"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Generating...
            </>
          ) : (
            'Generate Content ✨'
          )}
        </button>
      </div>
    </form>
  );
};
