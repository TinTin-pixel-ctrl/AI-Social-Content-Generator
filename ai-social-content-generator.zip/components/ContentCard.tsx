
import React, { useState, useCallback } from 'react';
import type { GeneratedContent } from '../types';
import { Platform } from '../types';
import { PlatformIcon, CopyIcon, CheckIcon } from './Icon';

interface ContentCardProps {
  platform: Platform;
  content: GeneratedContent;
}

export const ContentCard: React.FC<ContentCardProps> = ({ platform, content }) => {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = useCallback(() => {
    navigator.clipboard.writeText(content.post).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }, [content.post]);

  const platformColors: Record<Platform, string> = {
    [Platform.LinkedIn]: 'border-sky-500',
    [Platform.Twitter]: 'border-blue-400',
    [Platform.Instagram]: 'border-pink-500',
  };

  return (
    <div className={`bg-gray-800 rounded-lg shadow-lg overflow-hidden border-t-4 ${platformColors[platform]}`}>
      <div className="p-4 flex justify-between items-center bg-gray-800 border-b border-gray-700">
        <div className="flex items-center space-x-3">
          <PlatformIcon platform={platform} className="w-7 h-7 text-gray-300" />
          <h3 className="text-xl font-bold text-white">{platform}</h3>
        </div>
        <button
          onClick={copyToClipboard}
          className="p-2 rounded-md hover:bg-gray-700 text-gray-400 hover:text-white transition-colors duration-200"
          title="Copy post text"
        >
          {copied ? <CheckIcon className="w-5 h-5 text-green-400" /> : <CopyIcon className="w-5 h-5" />}
        </button>
      </div>
      
      <div className="md:flex md:space-x-4 p-4">
        <div className="md:w-1/2 flex-shrink-0">
          <img 
            src={content.imageUrl} 
            alt={`${platform} post image`} 
            className="rounded-md w-full object-cover shadow-md"
          />
        </div>
        <div className="mt-4 md:mt-0 md:w-1/2">
            <div className="text-gray-300 whitespace-pre-wrap bg-gray-900/50 p-3 rounded-md h-64 overflow-y-auto">
                {content.post}
            </div>
        </div>
      </div>
    </div>
  );
};
